import sys
import antigravity

def Traitement(lat, lon, reste):
	antigravity.geohash(lat, lon, reste.encode())

if __name__ == '__main__':
	try:
		lat = float(sys.argv[1])
	except ValueError:
	    print("Parametre 1 : mauvais format")
	
	try:
		lon = float(sys.argv[2])
	except ValueError:
	    print("Parametre 2 : mauvais format")
	
	try:
		dj = float(sys.argv[4])
		inStr = sys.argv[3] + '-' + str(dj)
	except ValueError:
	    print("Parametre 4 : mauvais format")

	Traitement (lat, lon, inStr)


	



	
	