pip --version
pip install --target=local_lib --upgrade --log pip.log git+https://github.com/jaraco/path.py.git