if __name__ == "__main__": 
	import local_lib.path

	filename = "log.txt"
	p = local_lib.path.Path('dirtest')
	p.mkdir_p()
	p = local_lib.path.Path('dirtest')
	p.chdir()
	fichier = open("data.txt", "w")
	fichier.write("Premier test d'écriture dans un fichier via Python")
	fichier.close()
	fichier = open("data.txt", "r")
	print(fichier.read())
	fichier.close()