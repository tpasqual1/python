if __name__ == "__main__": 
    import local_lib.requests
    import json
    import local_lib.dewiki.parser
    import sys

    adr = "https://fr.wikipedia.org/w/api.php?action=query&titles="\
           + sys.argv[1]\
           +"&prop=revisions&redirects=&rvprop=content&format=json&formatversion=2&utf8="
    req  = local_lib.requests.get(adr)
    #print (json.loads(req.text))
    data = json.loads(req.text)
    noRes = data['query']['pages'][0]
    if ('missing' in noRes):
        print("no result!")
        exit()

    content = data['query']['pages'][0]['revisions'][0]['content']
    p = local_lib.dewiki.parser.Parser()
    ficname = sys.argv[1].replace(" ","-")+".wiki"
    ficOut = open(ficname, "w") 
    #print(p.parse_string(content))
    try: 
        ficOut.write(p.parse_string(content))
        ficOut.close()
    except:
        print ("Erreur sur ecriture du fichier file.html")
        exit()
