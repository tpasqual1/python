import local_lib.requests
import json
import local_lib.dewiki.parser
import sys

adr = "https://fr.wikipedia.org/w/api.php?action=query&titles="\
       + sys.argv[1]\
       +"&prop=revisions&redirects=&rvprop=content&format=json"
req  = local_lib.requests.get(adr)
listeTitres = req.json()[1]
print (listeTitres)