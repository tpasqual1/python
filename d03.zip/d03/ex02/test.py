import local_lib.requests

listeAppellations = ["ACCESSOIRE","ALBUM","ALCOVE","APPLIQUE","AQUARELLE","ARGENTERIE","ARMOIRE","ASSIETTE","ASSIETTE CREUSE","ASSIETTE PLATE","ATHENIENNE","ATLAS","BAHUT","BALAI D'ATRE","BALDAQUIN","BANC","BANDEAU","VITRINE","VOILE NUPTIAL"]
for appellation in listeAppellations:
    url = "https://fr.wikipedia.org/w/api.php?action=opensearch&search=" + appellation + "&limit=10&namespace=0&format=json"
    #url = "http://domybiblio.net/search/search_api.php?type_search=subject&q=" + appellation + "&type_doc=all&period=&pageID=1&wp=true&idref=true&loc=true"
    #resultats = etree.parse(url)
    jsonfile = local_lib.requests.get(url)
    listeTitres = jsonfile.json()[1]
    print (listeTitres)
    NbReponses = len(listeTitres)
    listeURL = jsonfile.json()[3]
    forme_preferee = []
    toutes_reponses = []
    i = 0

    # for el in listeTitres:
    #      TITRE = el.upper()
    #      if (TITRE == appellation):
    #          forme_preferee.append(el)
    #          forme_preferee.append(listeURL[i])
    #      else:
    #          toutes_reponses.append(el + ";" + listeURL[i])
    #      i = i+1

    # print(appellation + "\t" + str(NbReponses) + "\t" + "|".join(forme_preferee) + "\t" +  "|".join(toutes_reponses) + "\n")
