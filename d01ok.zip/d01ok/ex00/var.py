def my_var():
	a = 42
	print (a, "est de type", type(a))
	b = "42"
	print (b, "est de type", type(b))
	c = "quarante-deux"
	print (c, "est de type", type(c))
	d = 42.0
	print (d, "est de type", type(d))
	e = True
	print (e, "est de type", type(e))
	f = [42]
	print (f, "est de type", type(f))
	g = {42 : 42}
	print (g, "est de type", type(g))
	h = (42,)
	print (h, "est de type", type(h))
	i = set()
	print (i, "est de type", type(i))

if __name__ == '__main__':
	my_var()
