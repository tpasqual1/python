def lectfic(file):
	fichier = open(file, "r")
	data = fichier.read().split(",")
	data[-1] = data[-1].replace('\n', '')
	for x in data:
		print (x)		
	fichier.close()

if __name__ == "__main__":
	lectfic("numbers.txt")