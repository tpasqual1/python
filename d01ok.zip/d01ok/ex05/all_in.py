def createListe (param):
	param = " ".join([elem for elem in param])
	listeparam = param.split(",")
	listeparam = [elem for elem in listeparam if (elem !=',' and elem !=' ') ]
	listeparam = [elem.lstrip().rstrip() for elem in listeparam]
	return listeparam

def testEtat (elem):
	if (elem.lower().title()) in states.keys():
		return ('1', capital_cities[states[elem.lower().title()]])
	else:
		return ('0', " ")

def testCapitale (elem):
	if (elem.lower().title()) in inv_capital.keys():
		return ('1', inv_states[inv_capital[elem.lower().title()]])
	else:
		return ('0', " ")

if __name__ == "__main__":
	import sys
	states = {
	"Oregon"    : "OR",
	"Alabama"   : "AL",
	"New Jersey": "NJ",
	"Colorado"  : "CO"
	}
	capital_cities = {
	"OR": "Salem",
	"AL": "Montgomery",
	"NJ": "Trenton",
	"CO": "Denver"
	}
	inv_capital = {v: k for k, v in capital_cities.items()}
	inv_states = {v: k for k, v in states.items()}
	listeok = createListe(sys.argv[1:])
	for param in listeok:
		ret = testEtat(param)
		if ret[0] == '1':
			print (ret[1], "is the capital of", param.lower().title())
		else:
			ret = testCapitale(param)
			if ret[0] == '1':
				print (param.lower().title(), "is the capital of", ret[1])
			else:
				print(param, "is neither a capital city nor a state")