def traitement(param):
	states = {
	"Oregon"    : "OR",
	"Alabama"   : "AL",
	"New Jersey": "NJ",
	"Colorado"  : "CO"
	}
	capital_cities = {
	"OR": "Salem",
	"AL": "Montgomery",
	"NJ": "Trenton",
	"CO": "Denver"
	}
	if param not in capital_cities.values():
		print ("Unknown capital city")
	else:	
		inv_capital = {v: k for k, v in capital_cities.items()}
		inv_states = {v: k for k, v in states.items()}
		print(inv_states[inv_capital[param]])


if __name__ == "__main__":
	import sys
	if len (sys.argv) == 2:
		traitement(sys.argv[1])
