from django.conf.urls import url

from . import views

urlpatterns = [
	url('^django', views.ex01),
	url('^affichage', views.affichage),
] 