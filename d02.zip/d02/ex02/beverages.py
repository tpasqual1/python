class HotBeverage():
	price = 0.30
	name = "hot beverage"

	def description(self):
		return "Just some hot water in a cup."

	def __str__(self):
		return "name : {}  \nprice : {} \ndescription : {} ".format(self.name, self.price, self.description()) 

class Coffee(HotBeverage):
	name = "coffee"
	price = 0.4

	def description(self):
		return "A coffee, to stay awake."

class Tea(HotBeverage):
	name = "tea"
	
	def description(self):
		return "Just some hot water in a cup."

class Chocolate(HotBeverage):
	name = "chocolate"
	price = 0.5

	def description(self):
		return "Chocolate, sweet chocolate..."

class Cappuccino(HotBeverage):
	name = "cappuccino"
	price = 0.45
	
	def description(self):
		return "Un po' di Italia nella sua tazza!"

if __name__ == "__main__":
	a = HotBeverage()
	print (a)
	b = Coffee()
	print (b)
	c = Tea()
	print (c)
	d = Chocolate()
	print (d)
	e = Cappuccino()
	print (e)