import beverages
import random

class CoffeeMachine:
    serveRandom = random.randint(0, 1)
    def __init__(self):
        self.use = 0
        
    class EmptyCup(beverages.HotBeverage):
        price = 0.90
        name = "empty cup"
        def description(self):
            return "An empty cup?! Gimme my money back!"

    class BrokenMachineException(Exception):
        def __str__(self):
            return "This coffee machine has to be repaired."
            
    def repair(self):
        self.use = 0
        print ('***** machine repared *****')

    def serve(self, classDeriv):
        print ('use ', self.use)
        n = random.randint(0, 1)
        self.use += 1
        if self.use > 9:
            raise self.BrokenMachineException()
        return classDeriv() if n < 1 else self.EmptyCup() 

if __name__ == "__main__":
    b = CoffeeMachine()
    try:
        print (b.serve(beverages.Tea))
        print (b.serve(beverages.Tea))
        print (b.serve(beverages.Chocolate))
        print (b.serve(beverages.Coffee))
        print (b.serve(beverages.Coffee))
        print (b.serve(beverages.Tea))
        print (b.serve(beverages.Chocolate))
        print (b.serve(beverages.Tea))
        print (b.serve(beverages.Chocolate))
        print (b.serve(beverages.Coffee))
        print (b.serve(beverages.Tea))
    except CoffeeMachine.BrokenMachineException as e:
        print (e)
    try:
        b.repair()
        print (b.serve(beverages.Tea))
        print (b.serve(beverages.Tea))
        print (b.serve(beverages.Chocolate))
        print (b.serve(beverages.Coffee))
        print (b.serve(beverages.Coffee))
        print (b.serve(beverages.Tea))
        print (b.serve(beverages.Chocolate))
        print (b.serve(beverages.Tea))
        print (b.serve(beverages.Chocolate))
        print (b.serve(beverages.Coffee))
        print (b.serve(beverages.Tea))
    except CoffeeMachine.BrokenMachineException as e:
        print (e)