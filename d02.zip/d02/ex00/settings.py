name = "Thierry Pasqualini"
rue = "19, rue Le Brun"
ville = "75013 Paris"
profession = "Informaticien"
age = 52