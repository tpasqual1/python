if __name__ == "__main__":
    import os
    import re
    import sys

    try:
        with open("settings.py",'r') as fic:
            dico = {}
            for line in fic:
                elem = line.split('=')
                dico['{'+elem[0].replace(' ','')+'}'] = elem[1].replace('\n','')

    except FileNotFoundError as e:
        print('le fichier {} n\'existe pas.'.format(e.filename))
        exit(1)
    except PermissionError as e:
        print('Droits de lecture absent sur le fichier{}'.format(e.filename))
        exit(2)
    except Exception as e:
        print('Une erreur a empeché l\'ouverture du fichier.'.format(e.strerror))
        exit(3)

#    print (os.path.getsize("myCV.template"))
    if (len(sys.argv) == 2):
        try:
            with open(sys.argv[1],'r') as ficCV:
                ficOut = open("file.html", "w") 
                for line in ficCV:
                    line = line.replace('\n','')
                    res = re.sub(r"(\{[a-zA-Z_0-9]+\})", lambda x: dico[x.group()].replace('"',''), line)  #x.group() : retourne la chaine qui matche dans la re
                    try: 
                        ficOut.write(res+'\n')
                    except:
                        print ("Erreur sur ecriture du fichier file.html")
                        exit(4)
                ficOut.close()
                ficCV.close()
                                              
        except FileNotFoundError as e:
            print('le fichier {} n\'existe pas.'.format(e.filename))
            exit(1)
        except PermissionError as e:
            print('Droits de lecture absent sur le fichier{}'.format(e.filename))
            exit(2)
        except Exception as e:
            print('Une erreur a empeché l\'ouverture du fichier.'.format(e.strerror))
            exit(3)


