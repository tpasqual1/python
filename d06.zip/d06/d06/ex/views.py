from django.shortcuts import render, HttpResponse
from django.conf import settings

# Create your views here.
def accueil(request):
	import random  
	if 'mycookie' in request.COOKIES:  #request.COOKIES est un dictionnaire : {'mycookie': 'Bob'}
		user_rand = request.COOKIES['mycookie']
		response = render(request, 'ex/accueil.html', {'user_rand': user_rand})
	else:
		user_rand = settings.USERNAME[random.randint(0, 9)]
		request.COOKIES['mycookie'] = user_rand
		response = render(request, 'ex/accueil.html', {'user_rand': user_rand})
		response.set_cookie('mycookie', user_rand, max_age=settings.SESSION_COOKIE_AGE)
	
	return response

def signin(request):
	return render(request, 'ex/signin.html')

def signup(request):
	if (request.method == 'POST'):
		form = MyForm(request.POST)
		if form.is_valid():
			return HttpResponse("Form Valid %s -----------   %s" %(form.cleaned_data['name'], form.cleaned_data['email']))
		else:
			return HttpResponse("NON")
	else:
		form = MyForm()
	return render(request, "ex/form.html", {'form' : form})
	return render(request, 'ex/signup.html')

#from .models import MyUser
# def inscription1(request):
# 	user = MyUser.objects.filter(username='my_user12')
# 	print('-------------- >', user)
# 	if not user:
# 		u = MyUser.objects.create_user(username='my_user12', password='test12', name='my_user12')
# 		print('u: ', u.username)
# 		print('u: ', u.password)
# 		response = render(request, 'inscription.html', {'info': 'inscription'})
# 		u.save()# save dans la base de donné
# 		u = MyUser.objects.all()
# 		print(' u :', u)
# 		return response
# 	else:
# 		return render(request, 'inscription.html', {'info': 'deja existant'})

from  ex.forms import Inscription
def inscription(request):
	if request.method == 'POST':
		form = Inscription(request.POST)
		if form.is_valid():
			username=form.cleaned_data['username']
			print ('>>>>>>>>>>>>>>>>>>>>username: ', username)
			name=form.cleaned_data['name']
			password=form.cleaned_data['password']
			user = form.objects.filter(email=name)
			if not user:
				u = form.objects.create_user(username=username, password=password, name=name)
				u.save()
	else:
		form = Inscription()
	return render(request, 'inscription.html', locals())


