from django.conf.urls import url

from . import views

urlpatterns = [
	url(r'^inscription', views.inscription),
	url(r'^signup', views.signup),
	url(r'^signin', views.signin),
	url(r'^$', views.accueil),
]