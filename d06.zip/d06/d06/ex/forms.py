from django import forms
class Inscription(forms.Form):
	username = forms.CharField()
	password = forms.CharField(widget=forms.PasswordInput)
	passwordCheck = forms.CharField(widget=forms.PasswordInput)
	name = forms.EmailField(label=u"Votre adresse mail")
	renvoi = forms.BooleanField(help_text=u"Cochez si vous souhaitez btenir une copie du mail envoyé.", required=False)

	def clean_username(self):
		username = self.cleaned_data['username']
		if "pizza" in username:
			raise forms.ValidationError("On ne veut pas entendre parler de pizza !")
		return username # Ne pas oublier de renvoyer le conten	
	def clean_password(self):
		password = self.cleaned_data['password']
		if "pizza" in password:
			raise forms.ValidationError("On ne veut pas entendre parler de pwd !")
		return password # Ne pas oublier de renvoyer le conten	

	def clean(self):
		cleaned_data = super(Inscription, self).clean()
		password = self.cleaned_data.get('password')
		passwordCheck = self.cleaned_data.get('passwordCheck')
		if password and passwordCheck: # Est-ce que sujet et message sont valides ?
			if password != passwordCheck:
				print (password, passwordCheck)
				self.add_error('password', 'Erreur sur ce champs')
				self.add_error('passwordCheck', 'Erreur sur ce champs')
				raise forms.ValidationError("Les mots de passe ne sont pas identiques !")
		return cleaned_data # N'oublions pas de renvoyer les données si tout est OK