from django.db import models

# # Create your models here.
from django.contrib.auth.models import AbstractUser #class django qui hérite de user de models

class MyUser(AbstractUser):
   name = models.CharField(max_length=64, null=False, unique=True)
   password = models.CharField(max_length=255, null=False, unique=False)
      
   def presentation(self):
       print('hello i am a custom user')

class MyTable():
   name = models.CharField(max_length=64, null=False, unique=True)
   password = models.CharField(max_length=255, null=False, unique=False)

       