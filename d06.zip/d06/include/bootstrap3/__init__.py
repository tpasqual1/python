# -*- coding: utf-8 -*-

__version__ = '8.2.2'
