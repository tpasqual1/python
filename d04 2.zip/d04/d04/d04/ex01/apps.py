from django.apps import AppConfig


class Ex01Config(AppConfig):
    name = 'ex01'
