from django.shortcuts import render

# Create your views here.

def ex01(request):
	liste = []
	liste.append("Ex01.")
	
	return render(request, 'ex01/django.html', {'text': liste})

def affichage(request):
	liste = []
	liste.append("Affichage.")
	
	return render(request, 'ex01/affichage.html', {'text': liste})
	