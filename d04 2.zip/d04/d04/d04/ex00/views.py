from django.shortcuts import render
from django.shortcuts import HttpResponse

# Create your views here.

def ex00(request):
	liste = []
	fic = open("/Users/tpasqual/python/d04/d04/Markdown.wiki", 'r')
	for line in fic:
		liste.append(line)
	fic.close()
	return render(request, 'ex00/index.html', {'text': liste})
	#return HttpResponse("Ex00...")

def withtemplate(request):
	return render(request, 'ex00/index.html')
	#return render(request, 'ex00/index.html', {})
