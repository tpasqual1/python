from django.apps import AppConfig


class Rush00Config(AppConfig):
    name = 'Rush00'
